# 性能：慢在哪里，怎么快一个量级

## 成本模型

CAD-MCP 是**逐图元**调用 COM：画一条带图层的线，静态数一遍代码路径大约 `6 + 2 × 图层数` 次跨进程往返——取 `ModelSpace` 1、`StartUndoMark`/`EndUndoMark` 2、`AddLine` 1，然后 `_apply_style` → `_ensure_layer` 要 `getattr Layers` + `Count` + 每层 `Item(i)`/`Name`（8 个建筑图层 = 16 次），最后设一次 `Layer`。

也就是说：**画一条线，真正在画线的只有 1 次往返，其余都是图层名解析、撤销标记、属性读写**。而且 `pywin32` 在没有 `gen_py` 缓存时走动态派发，每次成员访问还要多做一次 `GetIDsOfNames`，实际往返数约等于翻倍。

结论：瓶颈是「逐图元 COM 往返」这个架构，不是 Python 慢。换语言（含 C++）在同架构下只能拿到约 1.3–2×；改落图方式能拿到 10–100×。

## 三条落图路径

| 路径 | 机制 | 适用 | 代价 |
| --- | --- | --- | --- |
| 逐条调 MCP 工具 | 每个图元 1 次 COM 调用 | 少量图元、需要逐步检查、需要工具返回值 | 图元多了线性变慢 |
| **单次执行 `.scr` 脚本** | 一次 `send_command`，CAD 在进程内跑命令 | 几十～几千个图元、整批落图 | 画完才知道结果，脚本里不能交互 |
| 直写 DXF 再 `open_drawing` | 完全不经过 COM 绘图 | 上千图元、批量生成、无 CAD 也能算 | 需要 DXF 生成链路（如 `ezdxf`），不适用于改现有图纸 |

选择：先确认方案 → 图元数少（十几条）逐条画、逐步检查；几十个以上先 `.scr` 批量落图，再用 `screenshot`/`list_entities` 复核，细节和标注再逐条补。

## 批量落图步骤

```bash
# 1) 方案坐标 → MCP 调用序列（含墙/洞口/门窗）
python3 scripts/wall_plan.py plan.json > calls.json

# 2) 调用序列 → AutoCAD 脚本（CRLF + UTF-8 BOM，标注字高 250）
python3 scripts/plan_to_scr.py calls.json --out plan.scr --dimtxt 250
```

然后二选一落到 CAD 上——**首选 A**，服务端就在 CAD 那台机器上时不用拷任何文件：

- **A. `draw_script`**（本地扩展工具）：把脚本全文直接传进去，服务端落盘 + 一次执行，并回报 `completed` 与实体数前后差值：

  ```text
  draw_script(script=<plan.scr 的全文>, encoding="utf-8-sig")
  ```

- **B. 手工执行**：把 `plan.scr` 拷到 CAD 机器上，在 CAD 里执行 `SCRIPT` 选文件，或 `send_command("_.SCRIPT C:\\path\\plan.scr")`。

走直接调用通道（不用 MCP）时对应命令是：

```bash
python3 scripts/cad_direct.py script --file plan.scr    # 等价 draw_script
python3 scripts/cad_direct.py draw --calls calls.json   # 等价逐图元调用
```

脚本默认用 `UNDO BEGIN/END` 把整批包成一个撤销组：画错了 `undo` 一次就全撤回；脚本中途失败会留下未闭合的撤销组，在命令行执行一次 `UNDO END` 收尾即可（`--no-undo-group` 可关闭）。

## 注意

- **执行是异步的**：`send_command` 返回后脚本还在跑。提交后用 `list_entities` 核对实体数（`limit` 调大些）再 `screenshot`，别立刻断言"没画上"。
- **中文文字编码**：默认输出 UTF-8 + BOM；若房间名在 CAD 里变乱码，改用 `--encoding gbk` 重出脚本（GBK 下文本空格改用全角空格；编码不了的字符会直接报错而不是写出坏文件）。
- **文本里的空格**：命令行里空格等于回车，会截断文字。默认把空格替换为不换行空格，`--keep-spaces` 可关闭（会告警）。
- **填充**：`draw_hatch` 无法可靠脚本化（要交互选择边界），会被跳过并告警；填充仍用 MCP 工具单独做。
- **标注字高**：脚本开头写 `DIMTXT`；若图纸用的是自定义标注样式，字高可能仍被样式覆盖，需要时在 CAD 里改标注样式。
- **脚本是普通文本**，可以直接读、逐行核对坐标，也可以作为交付物交给合作方执行。

## 先量一次再优化

在 Windows 机器上比较三条路径的墙钟时间，同一套几何（例如 200 条线 / 一个完整外墙）：

1. 逐条 `draw_line`（记录 200 次的往返总耗时，顺便得到「每次调用的开销」）；
2. 生成 `plan.scr` 后一次 `SCRIPT` 执行；
3. 同样的几何用 DXF 生成再 `open_drawing` 加载。

再把结果除以图元数，就得到三种路径的「每次图元成本」。有了这三个数字，后续任何优化（包括要不要写 C++）都不必再猜。

## 服务端本地改动：图层缓存（已实现）

最小改动、最大收益的是**图层解析缓存**：`_ensure_layer` 每次都枚举全部图层（`Count` + 每层 `Item`/`Name`），把它按名称记忆化就能砍掉逐图元路径里约 90% 的往返。

这件事已经在本仓库的 `cad-mcp/` 本地副本里做完了（改动说明见 `cad-mcp/PATCHES.md`，差异补丁 `cad-mcp/patches/0001-layer-cache.patch`）：

- 首次图层解析整轮枚举一次、铺满缓存（8 个图层 = 18 次往返，只付一次）；
- 之后每条实体固定 **4 次往返**（`ModelSpace` 已缓存、图层命中缓存且直接写回真实图层名），上游同场景是 24 次；
- 换文档（新建/打开/关闭/重连）自动整体失效；图层被 CAD 界面删改导致写入失败时清缓存自愈。

离线回归测试（不需要 Windows、不需要 CAD，假 COM 计数）：

```bash
python3 cad-mcp/tests/test_layer_cache.py
```

这比把服务改写成 C++ 划算得多——同架构 C++ 大约只有 1.3–2×，还要重做 MCP 协议层（C++ 没有官方 MCP SDK）。真正需要质变速度时，选的是**架构**而不是语言：批量脚本 / DXF 生成，或者在仅 AutoCAD 的场景下用进程内的 ObjectARX（代价是每版本 SDK、编译工具链和多 CAD 兼容成本）。

注意：`cad-mcp/` 是本地副本，**不要去网上拉取上游代码**；将来要合并上游新版时，按 `PATCHES.md` 说明重新套用补丁并跑测试。
